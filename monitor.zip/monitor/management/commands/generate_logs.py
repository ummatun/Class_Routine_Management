from django.core.management.base import BaseCommand
from routine.models import Routine
from monitor.models import DailyClassLog
from teachers.models import Reschedule
from courses.models import Course
from datetime import date
from django.utils.timezone import now

class Command(BaseCommand):
    help = 'Generate today\'s class logs'

    def handle(self, *args, **kwargs):
        today = date.today()
        weekday = today.strftime('%A')

        routines = Routine.objects.filter(slot__day=weekday)
        for r in routines:
            DailyClassLog.objects.get_or_create(
                course=r.course,
                teacher=r.teacher,
                date=today,
                start_time=r.slot.start_time,
                end_time=r.slot.end_time,
                semester=r.batch,
                defaults={'status': 'pending'}
            )

        reschedules = Reschedule.objects.filter(reschedule_date=today)
        for r in reschedules:
            original = r.class_schedule
            course_code = original.subject.split(' - ')[0]
            try:
                course = Course.objects.get(code=course_code)
            except Course.DoesNotExist:
                continue
            DailyClassLog.objects.get_or_create(
                course=course,
                teacher=original.teacher,
                date=today,
                start_time=r.new_start_time or original.start_time,
                end_time=r.new_end_time or original.end_time,
                semester='3-2',  # adjust if needed
                defaults={'status': 'rescheduled'}
            )

        self.stdout.write(self.style.SUCCESS("Today's logs generated"))
